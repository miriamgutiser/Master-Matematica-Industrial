%LLamada del metodo para 100 y 1000 realizaciones respectivamente
[mu100, IC100] = estimar_esperanza(100)
[mu1000, IC1000] = estimar_esperanza(1000)