function [h,ssigma,snormh2] = houscero(x) 
%*****************************************************************
%OBJETIVO: HOUSCERO determina una matriz de Householder 
%          para transformar un vector x en un multiplo de 
%          la primera columna de la matriz identidad. 
% NO SE CONSTRUYE LA MATRIZ DE HOUSEHOLDER, basta dar el 
% vector h que la determina
%Ref: La funcion HOUSEZERO de MATCOM o el algoritmo 5.4.1 de Datta
%*****************************************************************
%EN ENTRADA:
%   x   el vector que se desea transformar.
%
%EN SALIDA:
%   h   El vector que determina la matriz de Householder H 
%       tal que Hx = [ssigma, 0, ...., 0]'. 
%
% ssigma El escalar que determina el vector transformado.
% snormh2 el cuadrado de la norma 2 del vector h

  s=length(x);
  t=norm(x,inf);
  x=x/t;% escalamos x para evitar posible overflow
  signo=sign(x(1));
  if signo==0
     signo=1;
  end
  snormx2=x(2:s)'*x(2:s);
  ssigma=signo*sqrt(x(1)*x(1)+snormx2); %signo*norm(x,2);
  h=x;
  h(1)=x(1)+ssigma;
  snormh2=h(1)*h(1)+snormx2;
  ssigma=-t*ssigma; %usando el escalamiento
