% Ejercicio 1 

fprintf('\n----- Parte 1: Serial Dates -----\n');

fecha = '31-May-2025';
sdn_excel = m2xdate(fecha);
sdn_matlab = x2mdate(sdn_excel);

fprintf('Fecha base: %s\n', fecha);
fprintf('Serial date en Excel: %.0f\n', sdn_excel);
fprintf('Serial date en MATLAB: %.0f\n', sdn_matlab);

% Último martes de junio 2025
martes = lweekdate(3, 2025, 6);  
martes_str = datestr(martes);
martes_excel = m2xdate(martes_str);
martes_matlab = x2mdate(martes_excel);

fprintf('\nÚltimo martes de junio de 2025: %s\n', martes_str);
fprintf('Serial date Excel: %.0f\n', martes_excel);
fprintf('Serial date MATLAB: %.0f\n', martes_matlab);

% Bono
fprintf('\n----- Parte 2: Bono y Flujos -----\n');

yield = 0.04;                        
couponRate = 0.05 / 4;               
settle = '31-May-2025';
maturity = '31-Dec-2027';
period = 4;                          
basis = 1;                           
endMonthRule = 1;
IssueDate = '01-Jan-2025';
nominal = 6000;

% Fechas de pago de cupones
fechas = cfdates(settle, maturity, period, basis, endMonthRule);
fprintf('Fechas de pago de cupones:\n');
disp(datestr(fechas));

% Precio limpio, cupón corrido y total
[pl, cc] = bndprice(yield, couponRate, settle, maturity, ...
    period, basis, endMonthRule, IssueDate);

pt = pl + cc;
valor_bono = pt * nominal / 100;

fprintf('\nPrecio limpio del bono: %.4f\n', pl);
fprintf('Cupón corrido (accrued): %.4f\n', cc);
fprintf('Precio total del bono: %.4f\n', pt);
fprintf('Valor total del bono para 6000 nominales: %.2f\n', valor_bono);

% Festivos 
fprintf('\n----- Parte 3: Días no hábiles en NYSE -----\n');

festivos = holidays(settle, maturity);
fprintf('Número de días no hábiles entre %s y %s: %d\n', settle, maturity, length(festivos));

fprintf('Días de no negociación:\n');
disp(datestr(festivos));
