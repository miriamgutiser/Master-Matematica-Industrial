%% Ejercicio 5
                                      
rate = 0.03;

settle1 = '31-May-2025';

%Empresa X - Opción de compra
vencimiento_X = '15-Sep-2025';
strike_X = 15;
volatility_X = 0.2;
dividendy_X = 0;
asset_X = 19;

%Empresa Y - Opción de compra
vencimiento_Y = '15-Dec-2025';
strike_Y = 3;
volatility_Y = 0.5;
dividendy_Y = 0.01;
asset_Y = 3.2;

% Empresa Z - Opción de venta
vencimiento_Z = '15-Mar-2026';
strike_Z = 3;
volatility_Z = 0.3;
dividendy_Z = 0.02;
asset_Z = 195;


% Tiempo hasta vencimiento (años)
tm_X1 = daysact(settle1, vencimiento_X) / 365;
tm_Y1 = daysact(settle1, vencimiento_Y) / 365;
tm_Z1 = daysact(settle1, vencimiento_Z) / 365;

% Empresa X - Call
[valor_X1, ~] = blsprice(strike_X, asset_X, rate, tm_X1, volatility_X, dividendy_X);
[delta_X1, ~] = blsdelta(strike_X, asset_X, rate, tm_X1, volatility_X, dividendy_X);
gamma_X1 = blsgamma(strike_X, asset_X, rate, tm_X1, volatility_X, dividendy_X);
vega_X1 = blsvega(strike_X, asset_X, rate, tm_X1, volatility_X, dividendy_X);

%Empresa Y - Call
[valor_Y1, ~] = blsprice(strike_Y, asset_Y, rate, tm_Y1, volatility_Y, dividendy_Y);
[delta_Y1, ~] = blsdelta(strike_Y, asset_Y, rate, tm_Y1, volatility_Y, dividendy_Y);
gamma_Y1 = blsgamma(strike_Y, asset_Y, rate, tm_Y1, volatility_Y, dividendy_Y);
vega_Y1 = blsvega(strike_Y, asset_Y, rate, tm_Y1, volatility_Y, dividendy_Y);

%Empresa Z - Put
[~, valor_Z1] = blsprice(strike_Z, asset_Z, rate, tm_Z1, volatility_Z, dividendy_Z);
[~, delta_Z1] = blsdelta(strike_Z, asset_Z, rate, tm_Z1, volatility_Z, dividendy_Z);
gamma_Z1 = blsgamma(strike_Z, asset_Z, rate, tm_Z1, volatility_Z, dividendy_Z);
vega_Z1 = blsvega(strike_Z, asset_Z, rate, tm_Z1, volatility_Z, dividendy_Z);


fprintf('\n--- Valoración al 31-May-2025 ---\n');
fprintf('Opción X (Call): Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_X1, delta_X1, gamma_X1, vega_X1);
fprintf('Opción Y (Call): Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_Y1, delta_Y1, gamma_Y1, vega_Y1);
fprintf('Opción Z (Put) : Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_Z1, delta_Z1, gamma_Z1, vega_Z1);

settle2 = '31-Aug-2025';
tm_X2 = daysact(settle2, vencimiento_X) / 365;
tm_Y2 = daysact(settle2, vencimiento_Y) / 365;
tm_Z2 = daysact(settle2, vencimiento_Z) / 365;

asset_X2 = 18;  
asset_Y2 = 3.7;  
asset_Z2 = 160;  

% Empresa X - Call
[valor_X, ~] = blsprice(asset_X2, strike_X, rate, tm_X2, volatility_X, dividendy_X);
[delta_X, ~] = blsdelta(asset_X, strike_X, rate, tm_X2, volatility_X, dividendy_X);
gamma_X = blsgamma(asset_X, strike_X, rate, tm_X2, volatility_X, dividendy_X);
vega_X = blsvega(asset_X, strike_X, rate, tm_X2, volatility_X, dividendy_X);

% Empresa Y - Call
[valor_Y, ~] = blsprice(asset_Y2, strike_Y, rate, tm_Y2, volatility_Y, dividendy_Y);
[delta_Y, ~] = blsdelta(asset_Y, strike_Y, rate, tm_Y2, volatility_Y, dividendy_Y);
gamma_Y = blsgamma(asset_Y, strike_Y, rate, tm_Y2, volatility_Y, dividendy_Y);
vega_Y = blsvega(asset_Y, strike_Y, rate, tm_Y2, volatility_Y, dividendy_Y);

% Empresa Z - Put
[~, valor_Z] = blsprice(asset_Z2, strike_Z, rate, tm_Z2, volatility_Z, dividendy_Z);
[~, delta_Z] = blsdelta(asset_Z, strike_Z, rate, tm_Z2, volatility_Z, dividendy_Z);
gamma_Z = blsgamma(asset_Z, strike_Z, rate, tm_Z2, volatility_Z, dividendy_Z);
vega_Z = blsvega(asset_Z, strike_Z, rate, tm_Z2, volatility_Z, dividendy_Z);

% Resultados
fprintf('\n--- Valoración al 31-Ago-2025 ---\n');
fprintf('Opción X (Call): Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_X, delta_X, gamma_X, vega_X);
fprintf('Opción Y (Call): Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_Y, delta_Y, gamma_Y, vega_Y);
fprintf('Opción Z (Put) : Valor=%.4f, Delta=%.4f, Gamma=%.4f, Vega=%.4f\n', valor_Z, delta_Z, gamma_Z, vega_Z);