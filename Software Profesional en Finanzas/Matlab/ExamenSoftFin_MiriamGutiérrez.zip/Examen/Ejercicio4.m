%% Ejercicio 4

yield = 0.03;               
couponRate = 0.05;          
settle = '31-May-2025';     
maturity = '31-Dec-2029';   
period = 2;                 % Aunque por defecto ya es dos
basis = 1;                  
endMonthRule = 1;           

IssueDate = '01-Jan-2024';          
FirstCouponDate = '31-Dec-2024';    

fechas = cfdates(settle, maturity, period, basis, endMonthRule, IssueDate, FirstCouponDate);
fprintf('Fechas de pago de flujos: \n')
disp(datestr(fechas))

[pl, cc] = bndprice(yield, couponRate, settle, maturity, period, basis, ...
    endMonthRule, IssueDate, FirstCouponDate);

precio_total = pl + cc;

fprintf('Precio limpio: %.4f\n', pl);
fprintf('Cupón corrido: %.4f\n', cc);
fprintf('Precio total del bono: %.4f\n', precio_total);

price = 104;

tir = bndyield(price, couponRate, settle, maturity, period, ...
    basis, endMonthRule, IssueDate, FirstCouponDate);

fprintf('TIR: %.4f (%.2f%%)\n', tir, 100 * tir);

[moddur, yeardur, perdur] = bnddury(yield, couponRate, settle, maturity, ...
    period, basis, endMonthRule, IssueDate, FirstCouponDate );

fprintf('Duración modificada: %.4f\n', moddur);
fprintf('Duración periódica: %.4f\n', perdur);
fprintf('Duración anual: %.4f\n', yeardur);
