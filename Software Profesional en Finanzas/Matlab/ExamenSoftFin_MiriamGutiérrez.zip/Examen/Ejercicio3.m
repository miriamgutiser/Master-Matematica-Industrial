%% Ejercicio 3

t = 0.04/12;   
n1 = 5*12;       
n2 = 7 *12;
p = 10000;    

[ca1, ip1, cp1, cm1] = amortize(t, n1, p, 0, 0);

fprintf('Cuota mensual (5 años): %.4f \n', cm1);
intereses_total1 = sum(ip1);
fprintf('Total intereses pagados (5 años): %.4f \n', intereses_total1);

[ca2, ip2, cp2, cm2] = amortize(t, n2, p, 0, 0);

fprintf('Cuota mensual (7 años): %.4f \n', cm2);
intereses_total2 = sum(ip2);
fprintf('Total intereses pagados (7 años): %.4f \n', intereses_total2);


