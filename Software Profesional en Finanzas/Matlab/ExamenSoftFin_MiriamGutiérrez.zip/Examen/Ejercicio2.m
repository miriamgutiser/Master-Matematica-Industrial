%% Ejercicio 2

% Vector de flujos 
% Inversión inicial
flujos(1) = -60000;

% Devoluciones mensuales
for i = 2:13
    flujos(i) = 6500;
end

tir = irr(flujos);
tir_inferior = tir * 0.9;
valor_capitalizado = fvfix(tir_inferior, 12, 6500);
valor_actualizado = pvfix(tir_inferior, 12, 6500);

% Resultados
fprintf('TIR de la inversión: %.4f (%.2f%% mensual)\n', tir, 100 * tir);
fprintf('TIR (10%% inferior): %.4f (%.2f%% mensual)\n', tir_inferior, 100 * tir_inferior);
fprintf('Valor capitalizado: %.2f \n', valor_capitalizado);
fprintf('Valor actualizado: %.2f \n', valor_actualizado);

