import math

radio=float(input('Introduce el radio del círculo: '))

area=math.pi*radio**2

print('El área del círculo es: %f' %area)
