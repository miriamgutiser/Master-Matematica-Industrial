# -*- coding: utf-8 -*-
"""
Created on Fri Apr  4 11:04:51 2025

@author: Miriam
"""

b = range(1,50,2) #números impares de 1 a 50
s = sum(b) # suma de los numeros
print('La suma de los números impares entre 1 y 50 es:', s)

#F9 hace que ejecute solo las lineas de código seleccionadas
