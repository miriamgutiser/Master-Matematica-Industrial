# -*- coding: utf-8 -*-
"""
Created on Fri Apr  4 12:06:34 2025

@author: Miriam
"""

import math as mt

radio = float(input('Introduzca el radio de un círculo:'))
area = mt.pi * radio**2
print('Área del círculo = %f' %(area)) #12 caracteres con 5 cifras decimales 