function y = prv(x)
y = x^2;
end
