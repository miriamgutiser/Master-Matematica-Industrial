function y = f1(x, y)
  % Ayuda de la función f1
  y = y + 2*x + 1;
  x = 1;
end
