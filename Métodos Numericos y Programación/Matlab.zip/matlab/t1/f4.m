function y = f4(x)
a = 3;
y = g(x^2);

function y = g(x)
y = x + a + 2;
end

end
