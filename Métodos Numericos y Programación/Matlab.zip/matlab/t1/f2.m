function y = f2(f)
  y = f(0,0) + f(1,1);
end
