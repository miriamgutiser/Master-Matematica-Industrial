function y = f3(x)
y = g(x^2);
end
function y = g(x)
y = x+2;
end
