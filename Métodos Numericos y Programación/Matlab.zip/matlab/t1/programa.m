a = 1;
b = 2; 
a+b;  % se guarda en ans
